package schedula;

public class EntityBean {

String classes; 
String Id;


}
